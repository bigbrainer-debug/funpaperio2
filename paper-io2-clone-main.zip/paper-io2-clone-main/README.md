# paper-io2-clone: Gameplay Proof of Concept 
I have recently been enjoying the browser game [Paper-io 2](https://paper-io.com/). 
While playing the game, I have wondered how I could go about recreating the territory-claiming game mechanic it is built around. This project was built in Unity, and is relatively unpolished- there's a bit of deprecated code laying around.

The most relevant code is in Assets/BaseController.cs - the logic behind updating claimed-territory edges based on player exit and entrance points.

![image](https://github.com/jdljake/paperio-clone/assets/20306303/08787885-37e3-4038-b71d-28b0623733a0)
